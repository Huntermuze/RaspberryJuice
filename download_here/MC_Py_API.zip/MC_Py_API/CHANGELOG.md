# Change Log

## 2020-04-19 v1.2.0

+ Brought up to date with latest version of RaspberryJuice 1.12.1

## 2018-05-01 v1.1.0 

+ packaged and released onto [PyPI](https://pypi.org)
+ it seemed ridiculous calling this v1.0.0 given the maturity of this library, so it has become v1.1.0

## in the past v1.0.0

+ the library was created it was used but never packaged.